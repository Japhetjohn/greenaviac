<?php
/**
 * Green AVIC CMS — Active Production Configuration
 * 
 * Automatically loads settings from .env file or falls back to defined defaults.
 */

defined('GREENAVIC_CORE') or define('GREENAVIC_CORE', true);

// ----------------------------------------------------------
// 1. Load .env Configuration
// ----------------------------------------------------------
$envLocations = [
    __DIR__ . '/.env',
    dirname(__DIR__) . '/.env'
];

foreach ($envLocations as $envPath) {
    if (file_exists($envPath) && is_readable($envPath)) {
        $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }
            if (strpos($line, '=') !== false) {
                [$key, $value] = explode('=', $line, 2);
                $key = trim($key);
                $value = trim($value, " \t\n\r\0\x0B\"'");
                if (!defined($key)) {
                    define($key, $value);
                }
            }
        }
        break;
    }
}

// ----------------------------------------------------------
// 2. Database Connection Defaults (if not set in .env)
// ----------------------------------------------------------
defined('DB_HOST') or define('DB_HOST', 'localhost');
defined('DB_NAME') or define('DB_NAME', 'u773570837_greenavic_cms');
defined('DB_USER') or define('DB_USER', 'u773570837_admin');
defined('DB_PASS') or define('DB_PASS', '@Kuulsinim45');
defined('DB_PORT') or define('DB_PORT', 3306);

// ----------------------------------------------------------
// 3. Security & Session Settings
// ----------------------------------------------------------
defined('SESSION_SECRET') or define('SESSION_SECRET', 'd89b37190e2f5b6697843232145eefab7c81a952d7e008fa9131d8bf62ca1234');
defined('SESSION_LIFETIME') or define('SESSION_LIFETIME', 86400); // 24 hours

// ----------------------------------------------------------
// 4. Subdomain URLs & File Paths
// ----------------------------------------------------------
defined('NEWSLETTER_URL') or define('NEWSLETTER_URL', 'https://newsletter.greenavic.org');
defined('ADMIN_URL')      or define('ADMIN_URL',      'https://admin.greenavic.org');
defined('MAIN_SITE_URL')  or define('MAIN_SITE_URL',  'https://greenavic.org');

define('NEWSLETTER_DIR', dirname(__DIR__) . '/newsletter');
define('ADMIN_DIR',      dirname(__DIR__) . '/admin');
define('UPLOADS_DIR',    NEWSLETTER_DIR . '/uploads');
define('UPLOADS_URL',    NEWSLETTER_URL . '/uploads');
